Dynamic power spectra
====================================

.. autofunction:: pyspedas.tdpwrspc
.. autofunction:: pyspedas.dpwrspc