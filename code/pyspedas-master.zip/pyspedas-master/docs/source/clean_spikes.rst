Clean spikes
====================================

.. autofunction:: pyspedas.clean_spikes 