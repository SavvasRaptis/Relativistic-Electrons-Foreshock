Subtract median
====================================

.. autofunction:: pyspedas.subtract_median