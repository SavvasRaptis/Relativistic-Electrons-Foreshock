Subtract average
====================================

.. autofunction:: pyspedas.subtract_average