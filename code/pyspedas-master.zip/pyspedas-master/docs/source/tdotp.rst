Dot products
====================================

.. autofunction:: pyspedas.tdotp 