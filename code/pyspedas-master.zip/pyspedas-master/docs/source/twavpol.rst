Wave polarization
====================================

.. autofunction:: pyspedas.twavpol
.. autofunction:: pyspedas.analysis.twavpol.wavpol