Cross products
====================================

.. autofunction:: pyspedas.tcrossp 