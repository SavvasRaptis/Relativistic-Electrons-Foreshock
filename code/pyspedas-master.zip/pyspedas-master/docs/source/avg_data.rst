Average data
====================================

.. autofunction:: pyspedas.avg_data 