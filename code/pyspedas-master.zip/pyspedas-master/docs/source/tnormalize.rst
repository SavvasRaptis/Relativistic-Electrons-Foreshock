Normalize vectors
====================================

.. autofunction:: pyspedas.tnormalize